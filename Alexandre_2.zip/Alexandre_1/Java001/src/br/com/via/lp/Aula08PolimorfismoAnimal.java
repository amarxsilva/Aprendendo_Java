package br.com.via.lp;

public class Aula08PolimorfismoAnimal {

	public void comer () {
		System.out.println("Animal Comendo!");
	}
}
