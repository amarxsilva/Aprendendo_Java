package br.com.via.lp;

public final class Aula07HerancaPessoaJuridica extends Aula07HerancaPessoa { 

	private String cnpj;
	
	private String getCNPJ;
	
	public Aula07HerancaPessoaJuridica() {
		
	}


	
	public void mostrarDados() {
		// TODO Auto-generated method stub
		
	}


	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}



	public String getGetCNPJ() {
		return getCNPJ;
	}



	public void setGetCNPJ(String getCNPJ) {
		this.getCNPJ = getCNPJ;
	}


}
