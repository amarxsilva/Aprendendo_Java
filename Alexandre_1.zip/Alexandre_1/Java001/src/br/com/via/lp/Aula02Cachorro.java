package br.com.via.lp;

public class Aula02Cachorro {

	int tamanho;
	String sexo;
	String raca;
	
	void latir() {
		
		System.out.println("Cachorro da " + raca + " do sexo: " + sexo + " tamanho: " +tamanho+ " Au, Au Au ");
	}
	
}
