package br.com.via.lp;

public class Aula05UsaEncapsulamento {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aula05Encapsulamento garrafa = new Aula05Encapsulamento();
		garrafa.setCapacidade(1000);
		garrafa.setTipomaterial("Vidro");
		garrafa.mostrarConteudo();
	}

}
