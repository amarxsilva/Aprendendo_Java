package br.com.via.lp;

public class Aula08PolimorfismoCao extends Aula08PolimorfismoAnimal {

	public void comer () {
		System.out.println("C�o Comendo!");
	
}
}
