package br.com.via.lp;

public interface Aula09InterfaceControle {

	void mudarCanal(int canal);
	
	void aumentarVolume(int taxa);
	
	void diminuirVolume(int taxa);
	
	boolean ligar ();
	
	boolean desligar();
	
	boolean ligardesligar();
	
}
