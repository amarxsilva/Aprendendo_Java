package br.com.via.lp;

public class Aula08PolimorfismoTigre extends Aula08PolimorfismoAnimal{

	public void comer () {
		System.out.println("Tigre Comendo!");
}
}
